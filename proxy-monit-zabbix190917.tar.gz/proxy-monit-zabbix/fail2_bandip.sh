#!/bin/bash

a=$1
file1=/tmp/kangle-bandIP.txt
file2=/tmp/baowang-bandIP.txt
fail2ban-client status kangle-cc|grep IP|awk -F':' '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/kangle-bandIP.txt
fail2ban-client status baowang-cc|grep IP|awk -F':' '{print $2}'|sed 's/^[[:space:]]*//' > /tmp/baowang-bandIP.txt
sed -i 's/ /\n/g' /tmp/*bandIP.txt

case $a in
   kangle)
          output=$(cat $file1)
          if [ "$output" == "" ];then
             echo "No IP band by kangle!"
          else
             echo $output
          fi
        ;;
   baowang)
          output=$(cat $file2)
          if [ "$output" == "" ];then
             echo "No IP band by baowang!"
          else
             echo $output
          fi
        ;;
    *)
          echo -e "\e[033mUsage: sh  $0 [kangle|baowang]\e[0m"

esac
