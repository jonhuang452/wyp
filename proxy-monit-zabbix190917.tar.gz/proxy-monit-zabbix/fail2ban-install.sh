#!/bin/bash

yum install epel-release fail2ban -y

# 判断centos版本
OSVER=`rpm -q centos-release|cut -d- -f3`

sshport=$(netstat -ntlp|grep sshd|awk '{print $4}'|grep 0.0.0|awk -F':' '{print $2}')

if [ $OSVER -eq 6 ];then
	[ -f /etc/sysconfig/iptables ] && { cat ./iptables > /etc/sysconfig/iptables; } || { mv iptables  /etc/sysconfig/; }
	sed -i "s/22/$sshport/g" /etc/sysconfig/iptables
	sed -i 's/BANACTION/iptables-ipset-proto4/' ./jail.local
	sed -i "s/22/$sshport/g" ./jail.local
	service iptables restart
	chkconfig iptables on
elif [ $OSVER -eq 7 ];then
	cat public > /etc/firewalld/zones/public.xml
	sed -i "s/22/$sshport/g" /etc/firewalld/zones/public.xml
	sed -i 's/BANACTION/firewallcmd-ipset/' ./jail.local
        sed -i "s/22/$sshport/g" ./jail.local
	firewall-cmd --restart
	systemctl enable firewalld
else
	echo "Please confirm your system version and set the firewall!"
	exit 1
fi
if [ !-d /vhs/kangle ];then
	sed -i '19,$'d ./jail.local
else
	mv ./baowang-cc.conf /etc/fail2ban/filter.d/
	mv ./kangle-cc.conf /etc/fail2ban/filter.d/
fi
\mv ./jail.local /etc/fail2ban/
service fail2ban start
