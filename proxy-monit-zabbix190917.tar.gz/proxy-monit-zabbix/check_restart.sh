#!/bin/bash
#Auth:Mark
#Date:2015-10-23 09:50pm
#check if server restart then alert

#set varaiable
num1=`/bin/cat /proc/uptime | /bin/awk -F '.' '{print $1}'`

#check
if [ $num1 -lt 600 ]
then
    echo " Server is Restarted,Please Check it !!!"
    exit 1
fi

