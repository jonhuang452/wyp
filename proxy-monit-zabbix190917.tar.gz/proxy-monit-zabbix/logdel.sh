#!/bin/bash

USER=$(who am i|awk '{print $1}')
if [ $USER != "root" ];then
        sudo su
fi

LOG_Dir="/vhs/kangle/var"
LOG_Dir2="/usr/local/nginx/logs"

Percent=`df -k|grep -Eo '[0-9]{2,3}%'|awk '{print int($1)}'`

find $LOG_Dir/*.log -mtime +2 -exec rm -f {} \;
find $LOG_Dir/*/*.access.log -mtime +2 -exec rm -f {} \;
find $LOG_Dir2/*.log -mtime +2 -exec rm -f {} \;
for Every in $Percent;do
    if [ $Every -ge 60 ];then
        Percent2=`df -k|grep -Eo '[0-9]{2,3}%'|awk '{print int($1)}'`
	for Per in $Percent2;do
        if [ $Per -ge 80 ];then
            find $LOG_Dir/*.log -size +2G |awk '{print "echo > " $0}' | bash
            find $LOG_Dir2/*.log -size +2G |awk '{print "echo > " $0}' | bash
            find $LOG_Dir2/off -size +2G |awk '{print "echo > " $0}' | bash
        fi
	done
    fi
done
