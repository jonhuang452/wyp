#!/bin/bash

FILE=/etc/sysconfig/network-scripts/ifcfg
DEV1=`ip a|grep BROADCAST|awk '{print $2}'|awk 'NR==1{print}'`
echo "GATEWAY=$GATE" >> $FILE-$DEV1
echo "DNS1=8.8.8.8" >> $FILE-$DEV1
echo "DNS2=8.8.4.4" >> $FILE-$DEV1
sed -i '/nameserver/d' /etc/resolv.conf

for DEV in `ip a|grep ROADCAST|awk '{print $2}'|tr -d ":"`;do

IP=$(ip a |egrep $DEV|grep inet|awk '{print $2}'|awk -F'/' '{print $1}')
MASK=`(ip a |egrep $DEV|grep inet|awk '{print $2}'|awk -F'/' '{print $2}')`
GATE=$(echo $IP |awk -F'.' '{print $1"."$2"." $3"."1}')

sed -i 's/BOOTPROTO=dhcp/BOOTPROTO=static/' $FILE-$DEV
echo "IPADDR=$IP" >> $FILE-$DEV
echo "PREFIX=$MASK" >> $FILE-$DEV

done
systemctl restart network
