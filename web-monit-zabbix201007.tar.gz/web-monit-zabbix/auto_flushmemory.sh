#!/bin/bash

TOTAL=$(free -m|grep Mem|awk '{print $2}')
USED=$(free -m|grep Mem|awk '{print $3}')

PERC=`awk 'BEGIN{printf "%.2f\n",('$[$TOTAL-$USED]'/'$TOTAL')}'`
FIN=`awk 'BEGIN{print '$PERC'*100}'`
if [ $FIN -lt 20 ];then
	sync;
	echo 3 > /proc/sys/vm/drop_caches
else
	exit 0
fi

