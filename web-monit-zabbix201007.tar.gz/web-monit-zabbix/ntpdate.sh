#!/bin/bash

/usr/sbin/ntpdate ntp.ig158.com >> /home/time.txt||\
/usr/sbin/ntpdate ntp1.aliyun.com >> /home/time.txt ||\
/usr/sbin/ntpdate 0.hk.pool.ntp.org >> /home/time.txt ||\
/usr/sbin/ntpdate ntp2.ig158.com >> /home/time.txt ||\
/usr/sbin/ntpdate time1.google.com >> /home/time.txt

#Only keep the latest 10 records

SUM=$(cat /home/time.txt |wc -l)
if [ $SUM -gt 10 ];then
	NU=$[$SUM-10]
	sed -i "1,$NU d" /home/time.txt
fi
