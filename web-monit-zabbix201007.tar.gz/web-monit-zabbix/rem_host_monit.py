#!/usr/bin/env python
#coding=utf-8
import os
import re
import sys
import json
import requests
import itertools
import socket
from contextlib import nested

a = sys.argv[1]
def ip_port():
  file1 = '/tmp/rem_ip.txt'
  file2 = '/tmp/rem_ports.txt'
  cmd = '''ss -a|awk '{print $NF}'|grep ":8"|grep -E "103.211|203.167|203.176"|'''
  cmd += '''awk -F":" '{print $2}'|sort -n|uniq > /tmp/rem_ports.txt '''
  os.system(cmd)
  with nested(open(file1,'r'), open(file2,'r')) as (line1,line2):
       ip = ''
       for line1 in lines1:
           if len(line1) <= 1:
               pass
           else:
               ip += line1.replace("\n", " ")
               ips = ip.rstrip().split(' ')

       port = ''
       for line2 in lines2:
           if len(line2) <= 1:
               pass
           else:
               port += line2.replace("\n"," ")
               ports = port.rstrip().split(' ')
  if len(ports) < 1:
      sys.exit()
  else:
      dest = (list(itertools.product(ips,ports)))
  des = []
  for i in range(len(dest)):
      seq = re.compile(",")
      address = (str(dest[i][0]), int(dest[i][1]))
      sk = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      sk.settimeout(3)
      status = sk.connect_ex(address)
      if status != 0:
         pass
      else:
         items = {'{#REM_IPAD}': (dest[i])[0], '{#REM_PORT}': dest[i][1]}
         des.append(items)
  print(json.dumps({'data': des}))
  return

def web_code(ip,port):
    resp = requests.get("http://"+ip+":"+port+"/monit_check/monit_check.html")
    web_code = resp.status_code
    print(web_code)
    return

def res_time(ip,port):
    resp = requests.get("http://"+ip+":"+port+"/monit_check/monit_check.html")
    res_time = resp.elapsed.microseconds/1000
    print(res_time)
    return

if __name__=='__main__':
    if a == 'check':
       ip_port();
#        ping(dest);
    elif a == 'code':
        ip = sys.argv[2]
        port = sys.argv[3]
        web_code(ip, port);
    elif a == 'time':
        ip = sys.argv[2]
        port = sys.argv[3]
        res_time(ip, port);
    else:
        print('invalid syntax')
