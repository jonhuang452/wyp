#!/bin/bash

#Auth:Stone Chen
#Date:2018-11-09
#install monit and zabbix

read -p "请输入验证字段: " HMeta
# 判断centos版本
OSVER=`rpm -q centos-release|cut -d- -f3`
setenforce 0 && sed -i 's/=enforcing/=disabled/' /etc/selinux/config
[ "$OSVER" -eq 6 -a -z "$(grep timestamps /etc/sysctl.conf)" -o "$(grep timestamps /etc/sysctl.conf|awk -F'=' '{print $2}')" -eq 0 -o -z "$(grep 200480 /etc/security/limits.conf)" ] && { sh youhua.sh; }
[ "$OSVER" -eq 7 -a -z "$(grep timestamps /etc/sysctl.conf)" -a -z "$(grep 200480 /etc/security/limits.conf)" ] && { sh youhua.sh; }
SSHPORT=$(ss -ntlp|grep sshd|awk '{print $4}'|grep ":::"|awk -F':' '{print $4}')
LOCA=$(grep localdomain /etc/hosts)
if [ "$LOCA"G = "G" ];then
	sed -i '1i\::1         localhost localhost.localdomain localhost6 localhost6.localdomain6' /etc/hosts
	sed -i '1i\127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4' /etc/hosts
fi
	
[ -z "$(grep zabbixSer.com /etc/hosts)" ] && { sed -i '2a\119.9.118.33 zabbixSer.com' /etc/hosts; }

#获取主机内网IP
IP=$(ip a |egrep 'eth|em|en'|grep inet |head -1|awk '{print $2}'|awk -F'/' '{print $1}')
# 确认主机名是否修改
HOSTNA=$(hostname)
if [ $HOSTNA = "localhost.localdomain" ];then
     read -p "input your hostname": HOSTNA
	if [ $OSVER -eq 6 ];then
		sed -i 's%localhost.localdomain%$HOSTNA%' /etc/sysconfig/network
		hostname $HOSTNA 
	elif [ $OSVER -eq 7 ];then
		hostnamectl set-hostname $HOSTNA --static
		hostnamectl set-hostname $HOSTNA --transient
	else
		echo -e "\033[31m Please confirm your system version! \033[0m"
		exit 1
	fi
else
	echo -e "\033[31m hostname is already set! \033[0m" 
fi
cd /root/monit-zabbix
###########################################################################################################
echo -e "\033[31m Start installing monit,please wait... \033[0m"
sleep 1

[ ! -d /etc/monit.d ] && { yum install -y epel-release monit; }

mv  monitrc /etc/monit.d/monitrc
sed -i "s%HostName%$HOSTNA%g" /etc/monit.d/monitrc
sed -i "s%HOSTIP%$IP%g" /etc/monit.d/monitrc
sed -i "s%22%$SSHPORT%g" /etc/monit.d/monitrc

if [ ! -d /home/sh ]; then 
	mkdir /home/sh
fi
mv logdel.sh /home/sh/
mv wildfly /etc/logrotate.d/
mv check_restart.sh  /home/sh/
mv auto_flushmemory.sh  /home/sh/
chmod +x /home/sh/*.sh
[ -z "$(grep auto_flushmemory /etc/crontab)" ] && { echo "*/10 * * * * root /bin/sh /home/sh/auto_flushmemory.sh > /dev/null 2>&1 &">> /etc/crontab; }
[ -z "$(grep logdel /etc/crontab)" ] && { echo "*/10 * * * * root /bin/sh /home/sh/logdel.sh &> /dev/null 2>&1 &">> /etc/crontab; }
monit
monit status
##################################################################################################
echo -e "\033[31m Start installing zabbix-agent,please wait... \033[0m"
sleep 1
# 判断之前是否安装过zabbix,卸载旧的
[ "$(rpm -qa|grep zabbix-agent)"X != "X" ] && { yum remove zabbix-agent* -y && rm -rf /etc/zabbix; }

if [ $OSVER -eq 6 ];then
	wget http://repo.zabbix.com/zabbix/4.0/rhel/6/x86_64/zabbix-agent-4.0.0-2.el6.x86_64.rpm && rpm -ivh ./zabbix-agent-4.0.0-2.el6.x86_64.rpm
	chkconfig zabbix-agent on
elif [ $OSVER -eq 7 ]
then
	wget http://repo.zabbix.com/zabbix/4.0/rhel/7/x86_64/zabbix-agent-4.0.0-2.el7.x86_64.rpm && rpm -ivh ./zabbix-agent-4.0.0-2.el7.x86_64.rpm
	systemctl enable zabbix-agent.service
else
	echo "Please confirm your system version!"
	exit 1
fi

[ ! -d /etc/zabbix ] && { echo "zabbix-agent installation failed"; exit 1; }
[ ! -d /etc/zabbix/scripts ] && mkdir /etc/zabbix/scripts
[ ! -d /var/log/zabbix ] && mkdir /var/log/zabbix

#修改/var/log/secure读权限
cp /etc/logrotate.d/syslog /etc/logrotate.d/syslog.bak
sed -ie '/secure/d' /etc/logrotate.d/syslog
echo '
/var/log/secure
{
    create 0644
    postrotate
        /bin/kill -HUP `cat /var/run/syslogd.pid 2> /dev/null` 2> /dev/null || true
    endscript
}
' >> /etc/logrotate.d/syslog

#权限文件
chown zabbix:zabbix /tmp/tcp_status.txt
chmod 644 /tmp/tcp_status.txt
chmod 644 /var/log/secure


# 复制配置文件

rm -f /etc/zabbix/zabbix-agentd.d/userparameter_mysql.conf
\mv ./lld-disks.py /etc/zabbix/scripts/discover_disk.py && chmod +x /etc/zabbix/scripts/discover_disk.py
\mv ./tcp_status  /etc/zabbix/scripts/tcp_status && chmod +x /etc/zabbix/scripts/tcp_status
\mv ./rem_host_monit.py  /etc/zabbix/scripts/rem_host_monit.py && chmod +x /etc/zabbix/scripts/rem_host_monit.py
\mv ./userparameter.conf /etc/zabbix/zabbix_agentd.d/

# 修改zabbix_agentd.conf配置文件
Zbx_Conf='/etc/zabbix/zabbix_agentd.conf'

sed -i "/# ListenIP=0.0.0.0/a ListenIP=$IP" $Zbx_Conf
sed -i "/# HostMetadata=/a HostMetadata=$HMeta" $Zbx_Conf
sed -i "s%Hostname=Zabbix server%Hostname=$HOSTNA%g" $Zbx_Conf
sed -i '/# RefreshActiveChecks=120/a RefreshActiveChecks=60' $Zbx_Conf
sed -i '/# BufferSize=100/a BufferSize=10000' $Zbx_Conf
sed -i '/# MaxLinesPerSecond=20/a MaxLinesPerSecond=200' $Zbx_Conf
sed -i '/# Timeout=3/a Timeout=30' $Zbx_Conf
#sed -i 's/# AllowRoot=0/AllowRoot=1/g' $Zbx_Conf
sed -i 's/# UnsafeUserParameters=0/UnsafeUserParameters=1/g' $Zbx_Conf
sed -i 's/Server=127.0.0.1/Server=zabbixSer.com/g' $Zbx_Conf
sed -i 's/ServerActive=127.0.0.1/ServerActive=zabbixSer.com:10051/g' $Zbx_Conf
sed -i 's/# UnsafeUserParameters=0/UnsafeUserParameters=1/g' $Zbx_Conf

# 启动zabbix-agent客户端

[ $OSVER -eq 6 ] && { /etc/init.d/zabbix-agent restart; } || { service zabbix-agent restart; }

service crond restart
rm -rf /root/web-monit-zabbix*
rm -rf /root/*.sh
