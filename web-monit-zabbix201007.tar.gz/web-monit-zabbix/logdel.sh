#!/bin/bash

Year=`date "+%Y"`

# 本脚本需要读取$Server_Home的值
#获取运行jboss/wildfly/tomecat的用户，也就是能够读取$Server_Home的值的用户
User=$(ps -ef |grep java|grep -v grep|awk '{print $1}')
Server_Home=$(su - $User -c 'echo $JBOSS_HOME')
if [ "$Server_Home"X == "X" ];then
    Server_Home=$(ps -ef |grep java|grep -v grep|awk '{print $(NF-1)}'|awk -F"=" '{print $2}')
fi

test ${Server_Home:?"Server_Home目录不正确！"}
Log_Dir="$Server_Home/standalone/log"
File_name=$(ls $Log_Dir |cut -d"." -f1|sort -u)

find $Log_Dir -maxdepth 4 -mtime +30 \( -name "*log*$Year*" -o -name "*$Year*log*" \) -exec rm -rf {} \;
find $Log_Dir -maxdepth 4 -mmin +360 ! -name '*gz*'  \( -name "*log*$Year*" -o -name "*$Year*log*" \)  -exec gzip -f -9 {} \;

find $Server_Home/bin -maxdepth 2 -mtime +30 \( -name "*log*$Year*" -o -name "*$Year*log*" \) -exec rm -rf {} \;
find $Server_Home/bin -maxdepth 2 -mmin +360 ! -name '*gz*' \( -name "*$Year*log" -o -name "*log*$Year*" \) -exec gzip -f -9 {} \;

Percent=`df -k|grep -Eo '[0-9]{2,3}%'|awk '{print int($1)}'`
for Per1 in $Percent;do
if [ $Per1 -ge 70 ];then
    [ -f $Server_Home/bin/nohup.out ]&&{ echo > $0; }
    [ -f $Log_Dir/nohup.out ]&&{ echo > $0; }
    find $Log_Dir -maxdepth 4 -mtime +20 -name "*$Year*gz" -exec rm -rf {} \;
    find $Server_Home/bin -maxdepth 2 -mtime +20 -name "*$Year*gz" -exec rm -rf {} \;
    find $Server_Home/standalone/tmp/vfs/deployment* -mtime +5|xargs rm -rf;
    find $Server_Home/standalone/tmp/vfs/temp* -mtime +5|xargs rm -rf;
    Percent2=`df -k|grep -Eo '[0-9]{2,3}%'|awk '{print int($1)}'`
    for Per2 in $Percent2;do
    if [ $Per2 -ge 70 ];then
        find $Log_Dir -maxdepth 4 -mtime +10 -name "*log*gz*" -exec rm -rf {} \;
        find $Log_Dir -size +3G -name "$Log_name*$Year*" -exec rm -rf {} \;
        find $Log_Dir -size +3G ! -name "*$Year*"  -name "*log*"| awk '{print "echo > " $0}' | bash
        find $Server_Home/bin -maxdepth 2 -mtime +10 -name "*log*gz*" -exec rm -rf {} \;
        find $Server_Home/bin -size +3G \( -name "*log*$Year*" -o -name "*$Year*log*" \)| awk '{print "echo > " $0}' | bash
        Percent3=`df -k|grep -Eo '[0-9]{2,3}%'|awk '{print int($1)}'`
        for Per3 in $Percent3;do
        if [ $Per3 -ge 70 ];then
            for Log_name in $File_name;do
                find $Log_Dir -name "*$Log_name*$Year*" | xargs -i ls -t {} | awk '{if(NR>5){print $0}}' | xargs -i rm -f {}
            done
        fi
        done
    fi
    done
fi
done

