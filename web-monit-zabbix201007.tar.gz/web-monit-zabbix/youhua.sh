#!/bin/bash

echo "nameserver 8.8.8.8" >> /etc/resolv.conf
echo "nameserver 8.8.4.4" >> /etc/resolv.conf


yum -y install epel-release
yum repolist
yum -y install python python-requests psmisc irqbalance telnet wget ntpdate sysstat screen tcpdump unzip openssh-clients gcc flex byacc libpcap ncurses ncurses-devel libpcap-devel iftop cronie expect
/etc/init.d/irqbalance start
chkconfig irqbalance on
chkconfig crond on

#关闭selinux
setenforce 0 && sed -i 's/=enforcing/=disabled/' /etc/selinux/config

#删除不必要的用户
cp /etc/passwd /etc/passwd.bak
cp /etc/group /etc/group.bak
userdel adm ;userdel lp ;userdel sync ;userdel shutdown ;userdel uucp ;userdel operator ;userdel games ;userdel gopher ;userdel ftp ;groupdel adm ;groupdel lp ;groupdel news ;groupdel uucp ;groupdel dip

#优化内核参数，在/etc/sysctl.conf文件中加入如下:
NU=$[$(grep -n "shmall" /etc/sysctl.conf |cut -d ":" -f 1)+1]
sed -i "$NU,$"d /etc/sysctl.conf

echo "
net.ipv4.ip_local_port_range = 1024 65535
net.core.rmem_max=16777216
net.core.wmem_max=16777216
net.ipv4.tcp_rmem=4096 87380 16777216
net.ipv4.tcp_wmem=4096 65536 16777216
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_tw_recycle = 0
net.ipv4.tcp_timestamps = 1
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_window_scaling = 0
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_sack = 0
net.core.netdev_max_backlog = 30000
net.ipv4.tcp_no_metrics_save=1
net.ipv4.tcp_max_orphans = 262144
net.ipv4.tcp_max_syn_backlog = 262144
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 2
" >> /etc/sysctl.conf
sysctl -p

#在/etc/security/limits.conf文件中加上如下几行:
if [ -z "$(grep "^*" /etc/security/limits.conf)" ];then
	sed -i '$a* soft nofile 200480' /etc/security/limits.conf 
	sed -i '$a* hard nofile 200480' /etc/security/limits.conf
fi

#在/etc/security/limits.d/*文件中替换一个参数:
FILENA=$(ls /etc/security/limits.d/)
sed -i 's/1024/8192/' /etc/security/limits.d/$FILENA
sed -i 's/4096/8192/' /etc/security/limits.d/$FILENA

#关闭mail提醒
echo "unset MAILCHECK" >> /etc/profile
source /etc/profile
ls -lth  /var/spool/mail/
cat /dev/null > /var/spool/mail/root

#修改时区
 
/usr/bin/expect <<EOF
spawn tzselect
expect "#?"
send "5\n"
expect "#?"
send "9\n"
expect "#?"
send "1\n"
expect "#?"
send "1\n"
expect eof
EOF


echo "TZ='Asia/Shanghai';export TZ ">> /etc/profile
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
echo "ZONE="Asia/Shanghai"" >/etc/sysconfig/clock
echo "UTC=false" >>/etc/sysconfig/clock                 
echo "ARC=false">>/etc/sysconfig/clock
sed -i '/ntpdate/d' /etc/crontab
sed -i '/command/a\*/20 * * * * root /bin/sh /home/sh/ntpdate.sh' /etc/crontab
[ ! -d /home/sh/ ] && mkdir /home/sh
\mv ./ntpdate.sh /home/sh/
chmod +x /home/sh/ntpdate.sh

#同步一下同步硬件时间
/bin/sh /home/sh/ntpdate.sh 
hwclock --systohc
hwclock -w
service crond restart
date -R
hwclock --show

#操作命令记录和超时时间
mkdir -p /var/log/.hist&&chmod 777 /var/log/.hist
cat com_his.txt >> /etc/profile
source /etc/profile

#跳板机批量维护免密登录
if [ ! -d /root/.ssh ];then
  mkdir /root/.ssh
  chmod 700 /root/.ssh
else
  if [ ! -f /root/.ssh/authorized_keys ];then
     mv id_rsa.pub /root/.ssh/authorized_keys
     chmod 600 /root/.ssh/authorized_keys
  else
     cat id_rsa.pub >> /root/.ssh/authorized_keys
  fi
fi

